<?php

namespace App\Http\Controllers;

use App\Article;
use App\Http\Resources\ArticleResource;
use App\Http\Resources\ArticlesResource;
use Illuminate\Http\Request;

use App\Comment;

use DB;

class ArticleController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return ArticlesResource
     */
    public function index()
    {


         $query = Comment::select(DB::raw("SUM(author_id) as y, article_id as name"))
        ->orderBy("created_at")
        ->groupBy('article_id')
        //->groupBy(DB::raw("month(created_at)"))
        ->get()->toArray(); // get data into array

        //dd($query);
       

        $chartArray = array(
            array(
                "name" => 'Donation Report',
                "colorByPoint" => true,
                "data" => $query
                )
            );  

       // return $chartArray;

        //series :  {!! $chartArray !!}

        return view('Highcharts.examples.pie-basic.index', ['chartArray'=>json_encode($chartArray,JSON_NUMERIC_CHECK)]);

      // $query = Article::with(['author', 'comments.author']);
       return new ArticlesResource($query);

        //return new ArticlesResource(Article::with(['author', 'comments.author'])->paginate());
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Article $article
     *
     * @return ArticleResource
     */
    public function show(Article $article)
    {
        ArticleResource::withoutWrapping();

        return new ArticleResource($article);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Article  $article
     * @return \Illuminate\Http\Response
     */
    public function edit(Article $article)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Article  $article
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Article $article)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Article  $article
     * @return \Illuminate\Http\Response
     */
    public function destroy(Article $article)
    {
        //
    }
}
